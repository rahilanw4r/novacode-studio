package com.novacode.studio.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novacode.studio.ui.theme.NovaAmber
import com.novacode.studio.ui.theme.NovaBorder
import com.novacode.studio.ui.theme.NovaBorderGlow
import com.novacode.studio.ui.theme.NovaCardGradient
import com.novacode.studio.ui.theme.NovaCyan
import com.novacode.studio.ui.theme.NovaEmerald
import com.novacode.studio.ui.theme.NovaIndigo
import com.novacode.studio.ui.theme.NovaObsidian
import com.novacode.studio.ui.theme.NovaPurple
import com.novacode.studio.ui.theme.NovaRose
import com.novacode.studio.ui.theme.NovaSurface
import com.novacode.studio.ui.theme.NovaSurfaceElevated
import com.novacode.studio.ui.theme.NovaTextMuted
import com.novacode.studio.ui.theme.NovaTextPrimary
import com.novacode.studio.ui.theme.NovaTextSecondary

/**
 * Modern frosted-glass surface card with subtle neon border.
 */
@Composable
fun NovaGlassCard(
    modifier: Modifier = Modifier,
    borderColor: Color = NovaBorder,
    glowEffect: Boolean = false,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(NovaCardGradient)
            .border(
                width = 1.dp,
                color = if (glowEffect) NovaBorderGlow else borderColor,
                shape = RoundedCornerShape(16.dp)
            )
            .padding(14.dp)
    ) {
        content()
    }
}

/**
 * Pulsing Status Indicator Badge for live Agent / Runtime states.
 */
@Composable
fun NovaStatusPill(
    statusText: String,
    isRunning: Boolean = false,
    color: Color = NovaEmerald,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by if (isRunning) {
        infiniteTransition.animateFloat(
            initialValue = 0.4f,
            targetValue = 1.0f,
            animationSpec = infiniteRepeatable(
                animation = tween(800),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulseAlpha"
        )
    } else {
        remember { mutableStateOf(1.0f) }
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = alpha))
        )
        Text(
            text = statusText,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace
        )
    }
}

/**
 * Virtual Developer Keyboard Strip for mobile coders.
 * Offers fast access to Esc, Tab, Ctrl, pipe, brackets, arrows, and quick terminal snippets.
 */
@Composable
fun DeveloperKeyToolbar(
    modifier: Modifier = Modifier,
    onKeyPress: (String) -> Unit,
    onSnippetRun: (String) -> Unit = {}
) {
    val devKeys = listOf(
        "ESC" to "\u001B",
        "TAB" to "\t",
        "CTRL-C" to "\u0003",
        "CTRL-D" to "\u0004",
        "|" to "|",
        "~" to "~",
        "/" to "/",
        "-" to "-",
        "_" to "_",
        ":" to ":",
        "$" to "$",
        "`" to "`",
        "\\" to "\\",
        "↑" to "\u001B[A",
        "↓" to "\u001B[B",
        "←" to "\u001B[D",
        "→" to "\u001B[C",
    )

    val quickSnippets = listOf(
        "npm run dev" to "npm run dev",
        "git status" to "git status",
        "git diff" to "git diff",
        "ls -la" to "ls -la",
        "clear" to "clear",
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(NovaSurface)
            .border(
                width = 1.dp,
                color = NovaBorder,
                shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
            )
            .padding(vertical = 4.dp)
    ) {
        // Dev Keys Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            devKeys.forEach { (label, value) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(NovaSurfaceElevated)
                        .border(1.dp, NovaBorder, RoundedCornerShape(6.dp))
                        .clickable { onKeyPress(value) }
                        .padding(horizontal = 9.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = NovaCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Quick Snippets Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            quickSnippets.forEach { (label, command) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(NovaIndigo.copy(alpha = 0.15f))
                        .border(1.dp, NovaIndigo.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .clickable { onSnippetRun(command) }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = NovaIndigo,
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = label,
                            color = NovaTextPrimary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

/**
 * Collapsible Thinking & Reasoning Chain Block (DeepSeek R1 / Claude 3.7 style).
 */
@Composable
fun ReasoningChainBlock(
    reasoningText: String,
    isStreaming: Boolean = false,
    tokenCount: Int = 0,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(isStreaming) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NovaPurple.copy(alpha = 0.08f))
            .border(1.dp, NovaPurple.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Psychology,
                    contentDescription = null,
                    tint = NovaPurple,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = if (isStreaming) "Thinking process…" else "Reasoning completed",
                    color = NovaPurple,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (tokenCount > 0) {
                    Text(
                        text = "($tokenCount tokens)",
                        color = NovaTextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
            Icon(
                imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                contentDescription = null,
                tint = NovaPurple,
                modifier = Modifier.size(18.dp)
            )
        }

        AnimatedVisibility(visible = expanded) {
            Column(modifier = Modifier.padding(top = 8.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(NovaObsidian)
                        .padding(10.dp)
                ) {
                    Text(
                        text = reasoningText.ifBlank { "Analyzing workspace context and planning actions..." },
                        color = NovaTextSecondary,
                        fontSize = 11.5.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}

/**
 * Tool Execution Card showing command execution, file modifications, or test results.
 */
@Composable
fun ToolExecutionCard(
    toolName: String,
    detail: String,
    isComplete: Boolean = true,
    isError: Boolean = false,
    modifier: Modifier = Modifier
) {
    val statusColor = when {
        isError -> NovaRose
        !isComplete -> NovaAmber
        else -> NovaEmerald
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(NovaSurfaceElevated)
            .border(1.dp, statusColor.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = when {
                toolName.contains("bash", ignoreCase = true) -> Icons.Default.Terminal
                toolName.contains("file", ignoreCase = true) -> Icons.Default.Code
                else -> Icons.Default.AutoAwesome
            },
            contentDescription = null,
            tint = statusColor,
            modifier = Modifier.size(16.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = toolName,
                color = NovaTextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = detail,
                color = NovaTextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 2
            )
        }
        NovaStatusPill(
            statusText = if (isComplete) "DONE" else "RUNNING",
            isRunning = !isComplete,
            color = statusColor
        )
    }
}
